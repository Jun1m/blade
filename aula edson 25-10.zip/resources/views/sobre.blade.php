<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre</title>
    <link rel="stylesheet" href="/css/estilos.css">
</head>
<body>
    <h2>O que é o Laravel?</h2>
        
    <p>Laravel é um framework PHP gratuito e de código aberto, utilizado no desenvolvimento de sistemas para web. <br>Algumas de suas principais características são permitir a escrita de um código mais simples e legível, e suporte<br> a recursos avançados que agilizam o processo de desenvolvimento.</p>
    <p>O Laravel é um dos frameworks PHP mais utilizados no mercado. Assim como outros do tipo, como Symfony e CodeIgniter,<br> um framework é um conjunto de ferramentas, recursos e funcionalidades, criado em uma determinada linguagem de programação<br> para facilitar e agilizar tarefas comuns de desenvolvimento de sistemas, como autenticação, localização, sessões e cache.<br>

    Criado pelo programador Tyler B. Otwell como uma alternativa mais avançada ao CodeIgniter, teve sua primeira versão lançada em 2011.<br> Desde então, tem recebido atualizações e contribuições constantes tanto do autor quanto da comunidade, posicionando-se como um verdadeiro <br>ecossistema para criação de sistemas para web. Com foco na sintaxe simples e concisa, seu mote é “O framework PHP dos artesãos da web”.</p>
    <h2>Principais Recursos</h2>
    <p>O Laravel é baseado na arquitetura MVC (acrônimo para Model-View-Controller, ou Modelo-Visão-Controle, em português). <br>MVC é um padrão de arquitetura de software focado em reuso de código, no qual ocorre a divisão da estrutura lógica de um<br> sistema em 3 camadas: a do Modelo, relacionada ao banco de dados; a de Visão, vinculada a visualização dos dados e das páginas;<br> e a do Controle, responsável pela conexão e transmissão de informações entre as camadas Modelo e Visão.

    Além disso, o Laravel<br> tem como principais recursos a utilização de um sistema modular para gerenciamento de dependências, diferentes formas de conexão<br> e acesso a banco de dados relacionais, um “motor” próprio de templates para criação de interfaces, além de vários programas e <br>serviços criados para facilitar a publicação e manutenção de sistemas criados com o framework.</p>
    <img src="img/laravel.png" alt="Deu ruim" width="100">
</body>
</html>